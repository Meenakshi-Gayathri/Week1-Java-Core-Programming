import java.util.Scanner;

public class FizzBuzzArray {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a positive integer: ");
        int number = input.nextInt();
        
        
        if (number < 1) {
            System.out.println("The number is not positive.");
        } else {
            String[] results = new String[number]; 
            
            
            for (int i = 0; i < number; i++) {
                if (i % 3 == 0 && i % 5 == 0) {
                    results[i] = "FizzBuzz"; 
                } else if (i % 3 == 0) {
                    results[i] = "Fizz";
                } else if (i % 5 == 0) {
                    results[i] = "Buzz";
                } else {
                    results[i] = String.valueOf(i); 
                }
            }
            
            
            for (int i=0;i<results.length;i++) {
                System.out.println("Position " + (i) + " = " + results[i]);
            }
        }
        
        
    }
}
